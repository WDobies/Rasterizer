#include <iostream>
#include <fstream>


int main()
{

    int width = 2;
    int height = 2;
    int r = 1;
    int g = 255;
    int b = 1;

    std::ofstream img;
    img.open("image.ppm");

    if (img.is_open()) {
        img << "P3\n";
        img << width<<" "<<height<< "\n";
        img << "255\n";

        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
               img <<r<<" "<<g<<" "<<b<<"\n";
            }
        }
    }

    img.close();
}
